# 📁 Frontend Project Structure

## Overview

This document outlines the clean, scalable folder structure and component architecture for the Real Estate website.

---

## 📂 Folder Structure

```
real-estate-frontend/
├── app/                          # Next.js 13+ App Router
│   ├── layout.tsx               # Root layout with providers
│   ├── page.tsx                 # Homepage (main entry)
│   └── globals.css              # Global styles
│
├── components/                   # Reusable React components
│   ├── layout/                  # Layout components
│   │   ├── MainLayout.tsx       # Main wrapper (Navbar + Content + Footer)
│   │   ├── Navbar.tsx           # Top navigation bar
│   │   ├── Footer.tsx           # Bottom footer
│   │   └── index.ts             # Export barrel
│   │
│   ├── sections/                # Page sections
│   │   ├── HeroSection.tsx      # Hero banner with search
│   │   ├── PropertyListingSection.tsx  # Property grid
│   │   ├── LocationSection.tsx  # Location tabs & cards
│   │   ├── CTASection.tsx       # Call-to-action
│   │   ├── NewsletterSection.tsx # Email subscription
│   │   └── index.ts             # Export barrel
│   │
│   ├── ui/                      # UI components (future)
│   │   └── (Button, Input, Card, etc.)
│   │
│   ├── providers/               # Context providers
│   │   └── QueryProvider.tsx   # React Query provider
│   │
│   └── index.ts                 # Main export barrel
│
├── lib/                         # Utility functions
│   ├── api.ts                   # Axios instance
│   ├── utils.ts                 # Helper functions
│   └── formatters.ts            # Formatting utilities
│
├── types/                       # TypeScript types
│   └── index.ts                 # Common types
│
├── hooks/                       # Custom React hooks
│   └── (useAuth, useProperties, etc.)
│
├── public/                      # Static assets
│   └── (images, icons, etc.)
│
├── styles/                      # Additional styles (if needed)
│   └── (custom CSS modules)
│
└── [config files]               # Configuration files
```

---

## 🏗️ Component Architecture

### Layout Components

#### 1. **MainLayout** (`components/layout/MainLayout.tsx`)
- **Purpose**: Wrapper for all pages
- **Contains**: Navbar + Main Content + Footer
- **Usage**: Wrap around page content

```tsx
<MainLayout>
  <YourPageContent />
</MainLayout>
```

#### 2. **Navbar** (`components/layout/Navbar.tsx`)
- **Purpose**: Top navigation bar
- **Features**:
  - Logo
  - Navigation links (Home, Properties, About, Contact)
  - User actions (Login, Sign Up, Wishlist, Notifications)
  - Mobile responsive menu
- **State**: Mobile menu toggle

#### 3. **Footer** (`components/layout/Footer.tsx`)
- **Purpose**: Bottom section with links and info
- **Contains**:
  - Company info & social links
  - Quick links
  - Property types
  - Contact information
  - Copyright & legal links

---

### Section Components

#### 1. **HeroSection** (`components/sections/HeroSection.tsx`)
- **Purpose**: Main banner with search functionality
- **Features**:
  - Background image with overlay
  - Headline & subheadline
  - Search box with filters:
    - Location input
    - Property type dropdown
    - Price range dropdown
    - Search button
  - Quick filter chips (For Sale, For Rent, Verified, Featured)
- **Responsive**: Mobile-first design

#### 2. **PropertyListingSection** (`components/sections/PropertyListingSection.tsx`)
- **Purpose**: Display featured properties in a grid
- **Features**:
  - Property cards with:
    - Image with hover effect
    - Badges (Featured, Verified)
    - Wishlist button
    - Price
    - Title & location
    - Features (beds, baths, area)
  - "View All Properties" button
- **Layout**: Responsive grid (1 col mobile, 2 col tablet, 3 col desktop)

#### 3. **LocationSection** (`components/sections/LocationSection.tsx`)
- **Purpose**: Explore properties by location
- **Features**:
  - Tab navigation (Dhaka, Chittagong, Sylhet)
  - Location cards with:
    - Background image
    - Location name
    - Property count
  - "View All Locations" button
- **State**: Active tab management
- **Layout**: Responsive grid (2 col mobile, 3 col tablet, 6 col desktop)

#### 4. **CTASection** (`components/sections/CTASection.tsx`)
- **Purpose**: Encourage user action
- **Features**:
  - Main CTA with buttons:
    - "Browse Properties"
    - "List Your Property"
  - Statistics/Features:
    - Properties listed
    - Happy customers
    - Years of excellence
- **Style**: Gradient background with white text

#### 5. **NewsletterSection** (`components/sections/NewsletterSection.tsx`)
- **Purpose**: Email subscription form
- **Features**:
  - Email input field
  - Subscribe button
  - Privacy note
  - Benefits list (Weekly Updates, Price Alerts, Expert Tips)
- **Style**: Light blue gradient background

---

## 📄 Page Structure

### Homepage (`app/page.tsx`)

**Hierarchy:**
```
MainLayout
  └── Navbar
  └── Main Content
      ├── HeroSection
      ├── PropertyListingSection
      ├── LocationSection
      ├── CTASection
      └── NewsletterSection
  └── Footer
```

**Flow:**
1. User lands on homepage
2. Sees hero section with search
3. Browses featured properties
4. Explores locations
5. Encouraged to take action (CTA)
6. Can subscribe to newsletter
7. Footer with additional links

---

## 🎨 Design Principles

### 1. **Component Reusability**
- Each component is self-contained
- Can be used independently
- Props for customization

### 2. **Separation of Concerns**
- Layout components handle structure
- Section components handle content
- UI components handle interactions

### 3. **Mobile-First Approach**
- All components responsive
- Tailwind CSS breakpoints:
  - `sm:` 640px
  - `md:` 768px
  - `lg:` 1024px
  - `xl:` 1280px

### 4. **Clean Code**
- TypeScript for type safety
- Functional components
- Clear naming conventions
- Comments explaining purpose

### 5. **Scalability**
- Easy to add new sections
- Easy to modify existing components
- Modular architecture

---

## 🔧 Component Props (Future)

### Current State
- Components use dummy data
- No props yet (self-contained)

### Future Enhancement
```tsx
// Example: PropertyListingSection with props
<PropertyListingSection 
  properties={propertiesData}
  title="Featured Properties"
  showViewAll={true}
/>
```

---

## 📱 Responsive Breakpoints

| Breakpoint | Width | Columns (Property Grid) |
|------------|-------|-------------------------|
| Mobile     | < 768px | 1 column |
| Tablet     | 768px - 1024px | 2 columns |
| Desktop    | > 1024px | 3 columns |

---

## 🎯 Next Steps

### Phase 1: Structure ✅ (COMPLETE)
- [x] Folder structure
- [x] Layout components (Navbar, Footer, MainLayout)
- [x] Section components (Hero, Properties, Locations, CTA, Newsletter)
- [x] Homepage assembly

### Phase 2: Styling (Next)
- [ ] Refine component styles
- [ ] Add animations & transitions
- [ ] Polish responsive design
- [ ] Add loading states

### Phase 3: Functionality
- [ ] Connect to API
- [ ] Add search functionality
- [ ] Implement filters
- [ ] Add user interactions

### Phase 4: Additional Pages
- [ ] Property listing page
- [ ] Property detail page
- [ ] User authentication
- [ ] Dashboard

---

## 💡 Usage Examples

### Import Components

```tsx
// Import layout
import MainLayout from '@/components/layout/MainLayout';

// Import sections
import { 
  HeroSection, 
  PropertyListingSection,
  LocationSection 
} from '@/components/sections';

// Use in page
export default function Page() {
  return (
    <MainLayout>
      <HeroSection />
      <PropertyListingSection />
      <LocationSection />
    </MainLayout>
  );
}
```

### Create New Section

```tsx
// components/sections/NewSection.tsx
export default function NewSection() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        {/* Your content */}
      </div>
    </section>
  );
}
```

---

## 📚 Resources

- **Tailwind CSS**: https://tailwindcss.com/docs
- **Next.js**: https://nextjs.org/docs
- **Lucide Icons**: https://lucide.dev/icons
- **TypeScript**: https://www.typescriptlang.org/docs

---

**Structure is complete and ready for development!** ✅
