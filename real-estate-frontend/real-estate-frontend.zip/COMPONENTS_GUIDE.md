# 🧩 Components Guide

Quick reference for all components in the Real Estate Frontend.

---

## 📐 Layout Components

### MainLayout
**File**: `components/layout/MainLayout.tsx`

**Purpose**: Main wrapper for all pages with Navbar and Footer

**Usage**:
```tsx
import MainLayout from '@/components/layout/MainLayout';

<MainLayout>
  <YourContent />
</MainLayout>
```

**Structure**:
- Navbar (sticky top)
- Main content area (flex-grow)
- Footer (bottom)

---

### Navbar
**File**: `components/layout/Navbar.tsx`

**Purpose**: Top navigation bar with menu and user actions

**Features**:
- Logo (left)
- Navigation links (center): Home, Properties, About, Contact
- User actions (right): Notifications, Wishlist, Login, Sign Up
- Mobile menu (hamburger icon)

**State**:
- `mobileMenuOpen`: boolean for mobile menu toggle

**Responsive**:
- Desktop: Full horizontal menu
- Mobile: Hamburger menu with dropdown

---

### Footer
**File**: `components/layout/Footer.tsx`

**Purpose**: Bottom section with links and information

**Sections**:
1. **Company Info**: Logo, description, social media links
2. **Quick Links**: Browse Properties, About, Contact, Blog
3. **Property Types**: Apartments, Houses, Villas, Commercial
4. **Contact Info**: Address, phone, email

**Bottom Bar**: Copyright and legal links

---

## 🎯 Section Components

### HeroSection
**File**: `components/sections/HeroSection.tsx`

**Purpose**: Main banner with background image and search box

**Elements**:
- Background image with gradient overlay
- Headline: "Find Your Dream Property"
- Subheadline
- Search box with 4 inputs:
  1. Location (text input)
  2. Property Type (dropdown)
  3. Price Range (dropdown)
  4. Search button
- Quick filter chips: For Sale, For Rent, Verified, Featured

**Height**: 600px

**Icons Used**: Search, MapPin, Home, DollarSign

---

### PropertyListingSection
**File**: `components/sections/PropertyListingSection.tsx`

**Purpose**: Display featured properties in a grid

**Property Card Contains**:
- Image (with hover zoom effect)
- Badges: Featured (yellow), Verified (green)
- Wishlist button (heart icon)
- Price (large, blue)
- Title (truncated to 1 line)
- Location (with MapPin icon)
- Features: Beds, Baths, Area (sqft)

**Grid Layout**:
- Mobile: 1 column
- Tablet: 2 columns
- Desktop: 3 columns

**Dummy Data**: 6 properties included

**Icons Used**: Bed, Bath, Maximize, MapPin, Heart

---

### LocationSection
**File**: `components/sections/LocationSection.tsx`

**Purpose**: Explore properties by location with tabs

**Features**:
- Tab navigation (Dhaka, Chittagong, Sylhet)
- Location cards with:
  - Background image
  - Gradient overlay
  - Location name
  - Property count
  - Hover effect (image zoom)

**Grid Layout**:
- Mobile: 2 columns
- Tablet: 3 columns
- Desktop: 6 columns

**State**: `activeTab` for tab switching

**Dummy Data**: 
- Dhaka: 6 locations
- Chittagong: 4 locations
- Sylhet: 3 locations

**Icons Used**: MapPin, TrendingUp

---

### CTASection
**File**: `components/sections/CTASection.tsx`

**Purpose**: Call-to-action with statistics

**Elements**:
1. **Main CTA**:
   - Headline: "Ready to Find Your Dream Home?"
   - Subheadline
   - Two buttons: "Browse Properties", "List Your Property"

2. **Statistics Grid** (3 columns):
   - Properties Listed: 5,000+
   - Happy Customers: 10,000+
   - Years of Excellence: 15+

**Background**: Blue gradient

**Icons Used**: ArrowRight, Home, Users, Award

---

### NewsletterSection
**File**: `components/sections/NewsletterSection.tsx`

**Purpose**: Email subscription form

**Elements**:
- Icon (Mail in blue circle)
- Headline: "Subscribe to Our Newsletter"
- Subheadline
- Email input + Subscribe button
- Privacy note
- Benefits grid (3 columns):
  - Weekly Updates
  - Price Alerts
  - Expert Tips

**Background**: Light blue gradient (blue-50 to blue-100)

**Icons Used**: Mail, Send

---

## 🎨 Styling Conventions

### Colors
- **Primary**: Blue-600 (`bg-blue-600`, `text-blue-600`)
- **Secondary**: Gray-900 (`bg-gray-900`, `text-gray-900`)
- **Background**: White, Gray-50
- **Text**: Gray-700, Gray-600

### Spacing
- **Section Padding**: `py-16` (4rem vertical)
- **Container**: `max-w-7xl mx-auto px-4 sm:px-6 lg:px-8`
- **Grid Gap**: `gap-4`, `gap-6`, `gap-8`

### Typography
- **H1**: `text-4xl md:text-5xl lg:text-6xl font-bold`
- **H2**: `text-3xl md:text-4xl font-bold`
- **H3**: `text-xl font-semibold`
- **Body**: `text-base` or `text-lg`

### Buttons
- **Primary**: `bg-blue-600 text-white hover:bg-blue-700`
- **Secondary**: `border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white`
- **Padding**: `px-6 py-3` or `px-8 py-4`
- **Border Radius**: `rounded-lg`

### Cards
- **Background**: `bg-white`
- **Shadow**: `shadow-md hover:shadow-xl`
- **Border Radius**: `rounded-lg`
- **Overflow**: `overflow-hidden`

---

## 📱 Responsive Design

### Breakpoints
```css
sm:  640px   /* Small devices */
md:  768px   /* Medium devices */
lg:  1024px  /* Large devices */
xl:  1280px  /* Extra large devices */
```

### Common Patterns
```tsx
// Grid responsive
className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3"

// Text responsive
className="text-2xl md:text-3xl lg:text-4xl"

// Padding responsive
className="px-4 sm:px-6 lg:px-8"

// Flex responsive
className="flex-col sm:flex-row"
```

---

## 🔄 State Management

### Current State
All components are **stateless** except:
- **Navbar**: `mobileMenuOpen` (boolean)
- **LocationSection**: `activeTab` (string)

### Future State (with API)
- Property data from API
- User authentication state
- Wishlist state
- Search filters state

---

## 🚀 Running the Project

```bash
# Navigate to project
cd real-estate-frontend

# Install dependencies (if not done)
npm install

# Run development server
npm run dev
```

**URL**: http://localhost:3001

---

## ✅ Component Checklist

### Layout Components
- [x] MainLayout
- [x] Navbar (with mobile menu)
- [x] Footer

### Section Components
- [x] HeroSection (with search box)
- [x] PropertyListingSection (6 property cards)
- [x] LocationSection (tabs + location cards)
- [x] CTASection (with stats)
- [x] NewsletterSection (email form)

### Homepage
- [x] All sections assembled
- [x] Proper hierarchy
- [x] Responsive design
- [x] Clean code structure

---

## 🎯 Next Development Steps

### 1. Styling Refinement
- Add smooth animations
- Improve hover effects
- Add loading states
- Polish mobile experience

### 2. Interactivity
- Search functionality
- Filter interactions
- Form validation
- Button actions

### 3. API Integration
- Fetch real property data
- Connect search to backend
- User authentication
- Wishlist functionality

### 4. Additional Components
- Property detail modal
- Image gallery
- Filter sidebar
- Pagination
- Sort dropdown

---

## 💡 Tips

1. **Import Components**: Use barrel exports from `index.ts` files
2. **Styling**: Use Tailwind utility classes
3. **Icons**: Import from `lucide-react`
4. **Images**: Use Next.js `Image` component for optimization
5. **Links**: Use Next.js `Link` component for navigation

---

**All components are ready and working!** ✅
