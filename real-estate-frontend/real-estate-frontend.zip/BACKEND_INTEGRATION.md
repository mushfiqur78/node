# Backend Integration Guide

## Overview
The frontend is now fully integrated with the backend API. All property data, images, and content are fetched dynamically from the backend.

## Current Status ✅

### Completed Features
1. **Dynamic Hero Section**
   - Property types fetched from API
   - Locations fetched from API
   - Purposes (Buy/Sell/Rent) fetched from API
   - Search functionality with query params

2. **Property Listings Section**
   - Real properties displayed from backend
   - Tab filtering (Buy/Rent) using purpose API
   - Real images from backend uploads folder
   - Price formatting (Crore for buy, /month for rent)
   - Loading states and empty states

3. **Location Section**
   - Real locations fetched from API
   - Properties filtered by selected location
   - Real images displayed
   - Compact card layout with actual data

## API Endpoints Used

### Properties
- `GET /api/v1/properties` - Get all approved properties
- Query params: `purpose`, `type`, `location`, `page`, `limit`, `sortBy`, `sortOrder`

### Property Types
- `GET /api/v1/property-types` - Get all property types (Residential, Commercial, etc.)

### Locations
- `GET /api/v1/locations` - Get all locations (Gulshan, Dhanmondi, etc.)

### Purposes
- `GET /api/v1/purposes` - Get all purposes (Buy, Sell, Rent)

## Image Handling

### Backend Image Storage
- Images are stored in: `real-estate/uploads/properties/`
- Backend returns relative URLs: `/uploads/properties/image.webp`

### Frontend Image Display
- Frontend converts relative URLs to full URLs using `toFullUrl()` function
- Example: `/uploads/properties/image.webp` → `http://localhost:5001/uploads/properties/image.webp`

### Image URL Conversion
```typescript
// lib/utils.ts
export const toFullUrl = (url: string): string => {
  if (!url) return '';
  if (url.startsWith('blob:')) return url;
  if (url.startsWith('http')) return url;
  return `${API_BASE}${url}`;
};
```

## Price Formatting

### Buy Properties
- Display format: `BDT X.XX Crore`
- Example: `BDT 1.65 Crore` (16,500,000 BDT)
- Calculation: `totalPrice / 10,000,000`

### Rent Properties
- Display format: `BDT X,XXX/month`
- Example: `BDT 45,000/month`
- Uses `rentPerMonth` field

## Data Flow

```
Backend API → React Query Hook → Component → UI
```

### Example: Property Listings
1. `useProperties()` hook fetches data from API
2. `PropertyListingSection` component receives data
3. Maps over properties and renders `PropertyCard` components
4. Each card displays real images using `toFullUrl()`

## Environment Variables

### Frontend (.env.local)
```env
NEXT_PUBLIC_API_URL=http://localhost:5001/api/v1
```

### Backend (.env)
```env
MONGO_URI=mongodb://localhost:27017/real-estate
PORT=5001
```

## How to Add Properties

### Option 1: Admin Panel (Recommended)
1. Login to admin panel: http://localhost:3000
2. Credentials: admin@gmail.com / 123456789
3. Navigate to Properties → Add New Property
4. Fill in details and upload images
5. Properties created by admin are automatically approved

### Option 2: Seed Script
```bash
cd real-estate
node scripts/seed-properties.js
```

## Important Notes

### Property Visibility
- Frontend API shows all **approved** properties (both admin and marketplace)
- Previously, it only showed `source: 'marketplace'` properties
- Now modified to show all approved properties regardless of source

### Property Status
- `approved` - Visible on frontend
- `pending` - Not visible (awaiting admin approval)
- `rejected` - Not visible

### Property Source
- `admin` - Created by super_admin (auto-approved)
- `marketplace` - Created by regular users (needs approval)

## Testing

### Check Backend API
```bash
# Get all properties
curl http://localhost:5001/api/v1/properties?limit=5

# Get properties by purpose (Buy)
curl http://localhost:5001/api/v1/properties?purpose=<purpose_id>&limit=5

# Get properties by location
curl http://localhost:5001/api/v1/properties?location=<location_id>&limit=5
```

### Check Frontend
1. Open browser: http://localhost:3001
2. Check Hero Section - dropdowns should show real data
3. Check Property Listings - should show real properties with images
4. Check Location Section - should show real locations and properties

## Troubleshooting

### Images Not Showing
1. Check if backend server is running on port 5001
2. Check if images exist in `real-estate/uploads/properties/`
3. Check browser console for CORS errors
4. Verify `NEXT_PUBLIC_API_URL` in `.env.local`

### No Properties Showing
1. Check if properties exist in database:
   ```bash
   cd real-estate
   node scripts/check-properties.js
   ```
2. Verify properties have `status: 'approved'`
3. Check backend API response:
   ```bash
   curl http://localhost:5001/api/v1/properties
   ```

### API Errors
1. Check backend server logs
2. Verify MongoDB is running
3. Check network tab in browser DevTools
4. Verify API base URL in frontend

## Next Steps

### Pending Features
1. **Property Detail Page** - Individual property view with full details
2. **Properties Listing Page** - Full list with pagination and filters
3. **Advanced Search** - Multi-filter search functionality
4. **Property Comparison** - Compare multiple properties
5. **Contact Forms** - Enquiry and contact functionality
6. **User Authentication** - Login/Register for users
7. **Wishlist** - Save favorite properties
8. **Map Integration** - Show properties on map

### Recommended Order
1. Create Properties Listing Page (`/properties`)
2. Create Property Detail Page (`/properties/[slug]`)
3. Implement Advanced Search
4. Add User Authentication
5. Add Wishlist and Contact Forms

## Scripts

### Check Properties
```bash
cd real-estate
node scripts/check-properties.js
```
Shows all properties with status, source, and details.

### Seed Properties
```bash
cd real-estate
node scripts/seed-properties.js
```
Creates sample properties (only if database is empty).

### Fix Properties
```bash
cd real-estate
node scripts/fix-properties.js
```
Fixes properties with missing or malformed images.

## Support

If you encounter any issues:
1. Check this documentation
2. Review backend logs
3. Check browser console
4. Verify environment variables
5. Ensure both servers are running (backend: 5001, frontend: 3001)
